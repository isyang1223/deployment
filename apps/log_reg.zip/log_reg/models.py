from __future__ import unicode_literals
from django.db import models
import re 
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
NAME_REGEX = re.compile(r'^[a-zA-Z]+$')
# Create your models here.

class UserManager(models.Manager):
    def basic_validator(self, postData):
        errors = {}
        if len(postData['first_name']) < 1:
            errors["first_name"] = "User's first name cannot be empty!"
        if len(postData['last_name']) < 1:
            errors["last_name"] = "User's last name cannot be empty!"
        if not NAME_REGEX.match(postData['first_name']):
            errors["first_name"] = "User's first name cannot contain any numbers or special characters!"
        if not NAME_REGEX.match(postData['last_name']):
            errors["last_name"] = "User's last name cannot contain any numbers or special characters!"
        if not EMAIL_REGEX.match(postData['email']):
            errors["email"] = "Invalid Email/Password!"
        if len(postData['password']) < 8:
            errors["password"] = "Invalid Email/Password!"
        if not postData['password'] == postData['password2']:
            errors["password2"] = "Password is not matching with confirm password!"
        return errors

class User(models.Model):
    fname = models.CharField(max_length = 255)
    lname = models.CharField(max_length = 255)
    email = models.CharField(max_length = 255)
    password = models.CharField(max_length = 255, default="")
    created_at = models.DateTimeField(auto_now_add = True)
    


    objects = UserManager()