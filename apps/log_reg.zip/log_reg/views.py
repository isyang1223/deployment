from django.shortcuts import render, HttpResponse, redirect
from django.contrib import messages
from .models import *
import bcrypt

def index(request):
    
    return render(request,'log_reg/index.html')

def success(request):
    data = {
        "loggeduser": User.objects.get(id=request.session["logged_id"])
    }
    
    return render(request,'log_reg/success.html', data)

def login(request):
    if request.method == 'POST':
        checklogin = User.objects.filter(email=request.POST['logemail'])
        
        if len(checklogin) > 0:
            logged=checklogin[0]
            if bcrypt.checkpw(request.POST['password'].encode(), logged.password.encode()) == True:
                request.session["logged_id"] = logged.id
                request.session["idk"] = "logged in"

                return redirect('/log_reg/success')
            else:
                return redirect("/log_reg")
        else:
            return redirect("/log_reg")


def registration(request):
    if request.method == 'POST':
        errors = User.objects.basic_validator(request.POST)
        if len(errors): 
            for tag, error in errors.iteritems():
                messages.error(request, error, extra_tags=tag)
            return redirect('/log_reg')
        else:
            firstname=request.POST['first_name']
            lastname=request.POST['last_name']
            emailadd=request.POST['email']

            hash1 = bcrypt.hashpw(request.POST['password'].encode(), bcrypt.gensalt())
            user = User.objects.create(fname=firstname, lname=lastname, email=emailadd, password=hash1 )
            request.session["idk"] = "registered"
            request.session["logged_id"] = User.objects.get(email=request.POST['email']).id
            return redirect('/log_reg/success')